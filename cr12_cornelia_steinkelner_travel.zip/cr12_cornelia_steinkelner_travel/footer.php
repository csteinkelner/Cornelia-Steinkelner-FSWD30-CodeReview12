	<footer>
			<div class="container fcontainer">
				<div class="row">
					<div class="col-lg-4 col-md-4 col-4 footer_text">
						<h3>Facebook</h3>
					</div>
					<div class="col-lg-4 col-md-4 col-4 footer_text">
						<h3>Twitter</h3>
					</div>
					<div class="col-lg-4 col-md-4 col-4 footer_text">
						<h3>Instagram</h3>
					</div>
				</div>
			<hr>
			<h5>&copy <?php echo Date('Y'); ?> <?php bloginfo('name'); ?> </h5>
			</div>
	</footer>
	
	<?php wp_footer(); ?>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/js/bootstrap.js"></script>
</body>
</html>